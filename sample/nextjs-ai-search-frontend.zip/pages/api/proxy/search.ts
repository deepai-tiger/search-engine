import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const query = req.query.q as string || '';
  const k = req.query.k as string || '10';
  // Proxy to backend (FastAPI). Adjust BACKEND_URL if needed.
  const BACKEND = process.env.BACKEND_URL || 'http://backend:8000';
  try {
    const url = new URL('/search', BACKEND);
    url.searchParams.set('q', query);
    url.searchParams.set('k', k);
    const r = await fetch(url.toString(), { method: 'GET' });
    const data = await r.json();
    res.status(200).json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
}
