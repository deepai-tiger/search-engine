# Next.js Frontend for AI Semantic Search

## Run locally

1. Install dependencies:
   ```
   npm install
   ```

2. Start dev server:
   ```
   npm run dev
   ```

This frontend expects the FastAPI backend to be reachable at the address configured in `process.env.BACKEND_URL`.
When running with Docker Compose (provided), the backend service name is `backend` and the frontend uses an nginx reverse proxy.

