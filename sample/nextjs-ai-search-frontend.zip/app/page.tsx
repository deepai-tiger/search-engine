"use client";

import { useState } from "react";
import axios from "axios";

export default function HomePage() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([] as any[]);
  const [loading, setLoading] = useState(false);

  const search = async () => {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const res = await axios.get(`/api/proxy/search`, { params: { q: query } });
      setResults(res.data.results || []);
    } catch (e) {
      console.error(e);
      setResults([]);
    }
    setLoading(false);
  };

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: 20 }}>
      <h1 style={{ textAlign: "center", fontSize: 28, marginBottom: 20 }}>AI Semantic Search</h1>

      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        <input
          style={{ flex: 1, padding: 10, borderRadius: 6, border: "1px solid #ddd" }}
          placeholder="Search..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button onClick={search} style={{ padding: "10px 16px", borderRadius: 6, background: "#0b6cff", color: "white", border: "none" }}>
          Search
        </button>
      </div>

      {loading && <p style={{ textAlign: "center" }}>Searching...</p>}

      {!loading && results.length > 0 && (
        <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
          {results.map((r: any, i: number) => (
            <li key={i} style={{ background: "white", padding: 16, borderRadius: 8, boxShadow: "0 1px 3px rgba(0,0,0,0.08)", marginBottom: 12 }}>
              <div style={{ fontWeight: 600, marginBottom: 6 }}>{r.text}</div>
              <div style={{ fontSize: 12, color: "#666", marginTop: 8 }}>Score: {r.score}</div>
            </li>
          ))}
        </ul>
      )}

      {!loading && results.length === 0 && query && <p style={{ textAlign: "center", color: "#666" }}>No results</p>}
    </div>
  );
}
