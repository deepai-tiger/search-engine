from elasticsearch import Elasticsearch, helpers
from .config import ES_URL, INDEX_NAME, EMBEDDING_MODEL
from sentence_transformers import SentenceTransformer
import json

es = Elasticsearch(ES_URL, timeout=30)
model = SentenceTransformer(EMBEDDING_MODEL)

INDEX_BODY = {
    "mappings": {
        "properties": {
            "text": {"type": "text"},
            "embedding": {
                "type": "dense_vector",
                "dims": model.get_sentence_embedding_dimension(),
                "index": True,
                "similarity": "cosine"
            }
        }
    }
}

def init_index():
    if not es.indices.exists(index=INDEX_NAME):
        es.indices.create(index=INDEX_NAME, body=INDEX_BODY)
    return True

def index_document(id: str, text: str):
    emb = model.encode(text).tolist()
    res = es.index(index=INDEX_NAME, id=id, document={"text": text, "embedding": emb})
    return res.get("result") in ("created","updated")

def bulk_index_from_file(path: str):
    with open(path,"r",encoding="utf-8") as f:
        data=json.load(f)
    actions=[]
    for i,doc in enumerate(data):
        emb=model.encode(doc["text"]).tolist()
        actions.append({
            "_op_type":"index",
            "_index":INDEX_NAME,
            "_id":doc.get("id",str(i)),
            "text":doc["text"],
            "embedding":emb
        })
    helpers.bulk(es,actions)
    return len(actions)

def search(query: str, k: int = 5):
    q_emb = model.encode(query).tolist()
    body = {
        "size": k,
        "query": {
            "bool": {
                "should": [
                    {"match": {"text": {"query": query, "boost": 1}}},
                    {"knn": {"field": "embedding", "query_vector": q_emb, "k": k, "num_candidates": 100}}
                ]
            }
        }
    }
    res = es.search(index=INDEX_NAME, body=body)
    return [{"id":h["_id"],"score":h["_score"],"text":h["_source"]["text"]} for h in res["hits"]["hits"]]
