import os
ES_URL = os.getenv("ES_URL", "http://localhost:9200")
INDEX_NAME = os.getenv("INDEX_NAME", "ai-search")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
