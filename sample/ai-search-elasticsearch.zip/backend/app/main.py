from fastapi import FastAPI, HTTPException
from .search import init_index, search, index_document, bulk_index_from_file

app = FastAPI(title="AI Semantic Search API")

@app.on_event("startup")
async def startup_event():
    init_index()

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/index")
def index_doc(id: str, text: str):
    ok = index_document(id, text)
    if not ok:
        raise HTTPException(status_code=500, detail="Index error")
    return {"indexed": id}

@app.post("/index_bulk")
def index_bulk():
    count = bulk_index_from_file("/app/sample_data.json")
    return {"indexed_count": count}

@app.get("/search")
def api_search(q: str, k: int = 5):
    return {"query": q, "results": search(q, k=k)}
