import streamlit as st
import requests

BACKEND_URL = "http://backend:8000"

st.title("AI Semantic Search — Demo")
q = st.text_input("Enter your query")

if st.button("Search") and q:
    r = requests.get(f"{BACKEND_URL}/search", params={"q": q, "k": 10})
    data = r.json()
    for i, hit in enumerate(data.get("results", []), 1):
        st.write(f"**{i}.** (score: {hit['score']}) {hit['text']}")
