# Simple script to add sample docs (requires requests and python)
import requests
docs = [
    "The quick brown fox jumps over the lazy dog.",
    "FastAPI is a modern, fast web framework for Python.",
    "Qdrant is a vector database for production-ready similarity search."
]
for d in docs:
    r = requests.post("http://localhost:4000/api/doc", json={"text":d})
    print(r.status_code, r.text)
