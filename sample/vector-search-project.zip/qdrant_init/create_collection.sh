#!/bin/sh
# call after qdrant is up
curl -X PUT "http://localhost:6333/collections/docs" -H "Content-Type: application/json" -d '{
  "vectors": {
    "size": 384,
    "distance": "Cosine"
  }
}'
echo "collection created (if not existed)."
