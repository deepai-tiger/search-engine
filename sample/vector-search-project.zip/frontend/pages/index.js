import { useState } from 'react';
import useSWR from 'swr';

const fetcher = (url, opts) => fetch(url, opts).then(r => r.json());

export default function Home() {
  const [text, setText] = useState('');
  const [docs, setDocs] = useState([]);
  const [query, setQuery] = useState('');
  const { data: searchRes, mutate } = useSWR(query ? ['/api/search', query] : null, (url, q) =>
    fetcher('/api/search', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({query:q, top_k:5})})
  );

  const addDoc = async () => {
    if (!text) return;
    await fetch('/api/doc', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({text})});
    setText('');
    // optionally refresh local list
  };

  const doSearch = async () => {
    mutate();
  };

  return (
    <main style={{maxWidth:800, margin:'40px auto', fontFamily:'Inter,system-ui,Arial'}}>
      <h1>Vector Search Demo</h1>
      <section style={{marginBottom:30}}>
        <h2>Ingest Document</h2>
        <textarea value={text} onChange={e=>setText(e.target.value)} rows={4} style={{width:'100%'}} />
        <button onClick={addDoc} style={{marginTop:8}}>Add Document</button>
      </section>

      <section>
        <h2>Search</h2>
        <input value={query} onChange={e=>setQuery(e.target.value)} style={{width:'100%'}} />
        <button onClick={doSearch} style={{marginTop:8}}>Search</button>

        <div style={{marginTop:16}}>
          {searchRes ? (
            <ul>
              {searchRes.result.map(r => (
                <li key={r.id}><strong>score:</strong> {r.score.toFixed(4)} — {r.payload?.text ?? '[no text]'} </li>
              ))}
            </ul>
          ) : <p>No results</p>}
        </div>
      </section>
    </main>
  );
}
