# Vector Search Project (Next.js + Node + Python Embedder + Qdrant + Docker)

This example project demonstrates a simple semantic search stack:
- **Next.js** frontend (React) providing a minimal UI to add documents and search.
- **Node.js (Express)** backend that proxies requests and stores metadata.
- **Python Embedder (FastAPI)** that generates embeddings using `sentence-transformers` (local model).
- **Qdrant** as the vector database.
- **Docker Compose** to run everything, plus **Nginx** as a reverse proxy.

## Features
- Ingest documents (text + metadata) -> embedder -> Qdrant upsert
- Semantic search by sending text query -> embedder -> Qdrant search
- Example docker-compose to run services locally.

## How to run (example)
1. Install Docker & Docker Compose.
2. From project root:
   ```bash
   docker compose up --build
   ```
3. Open `http://localhost/` (Nginx reverse proxy) to view the Next.js app.

## Notes
- The embedder uses `sentence-transformers/all-MiniLM-L6-v2` (downloaded on first run).
- You can switch to an external embedding API by modifying the embedder or backend.
- This is a starter project — adapt for production (auth, scaling, metrics, backups).

