const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(bodyParser.json());

const QDRANT_URL = process.env.QDRANT_URL || 'http://qdrant:6333';
const EMBEDDER_URL = process.env.EMBEDDER_URL || 'http://embedder:8001';

app.post('/api/doc', async (req, res) => {
  // Accepts { text, metadata? }
  const { text, metadata } = req.body;
  if (!text) return res.status(400).json({error:'text required'});
  try {
    // 1) get embedding from embedder service
    const embResp = await axios.post(EMBEDDER_URL + '/embed', {texts:[text]});
    const vector = embResp.data[0];
    const id = uuidv4();
    // 2) upsert into qdrant
    const payload = { text, metadata: metadata || {} };
    await axios.put(QDRANT_URL + `/collections/docs/points`, {
      points: [{ id, vector, payload }]
    });
    return res.json({ok:true, id});
  } catch (err) {
    console.error(err?.response?.data || err.message);
    return res.status(500).json({error:'failed to ingest'});
  }
});

app.post('/api/search', async (req, res) => {
  const { query, top_k } = req.body;
  if (!query) return res.status(400).json({error:'query required'});
  try {
    const embResp = await axios.post(EMBEDDER_URL + '/embed', {texts:[query]});
    const vector = embResp.data[0];
    // call qdrant search
    const q = {
      vector,
      top: top_k || 5,
      with_payload: true,
      params: { hnsw_ef: 64 }
    };
    const r = await axios.post(QDRANT_URL + `/collections/docs/points/search`, q);
    // Map results
    const result = (r.data.result || []).map(item => ({
      id: item.id,
      score: item.score,
      payload: item.payload
    }));
    return res.json({result});
  } catch (err) {
    console.error(err?.response?.data || err.message);
    return res.status(500).json({error:'search failed'});
  }
});

app.get('/api/health', (req,res)=>res.json({ok:true}));

app.listen(4000, ()=>console.log('backend running on 4000'));
