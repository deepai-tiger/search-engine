from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from sentence_transformers import SentenceTransformer
import numpy as np

app = FastAPI()
# Use a small but effective model for demo
MODEL_NAME = "all-MiniLM-L6-v2"
model = SentenceTransformer(MODEL_NAME)

class Texts(BaseModel):
    texts: List[str]

@app.post('/embed')
async def embed(texts: Texts):
    embs = model.encode(texts.texts, convert_to_numpy=True, normalize_embeddings=True)
    # convert to python lists
    return [e.tolist() for e in embs]
